package org.eclipse.birt.report.model.tests.matrix;

import org.eclipse.birt.report.model.api.simpleapi.IMultiRowItem;


public interface IMatrix extends IMultiRowItem
{

	String getMethod1();
	
}
