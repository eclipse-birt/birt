package org.eclipse.birt.report.model.tests.box;

import org.eclipse.birt.report.model.api.simpleapi.IMultiRowItem;


public interface IBox extends IMultiRowItem
{

	String getMethod1();
	
}
